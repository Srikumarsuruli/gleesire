<?php
// Include header
require_once "includes/header.php";

// Check if user has privilege to access this page
if(!hasPrivilege('view_leads')) {
    header("location: index.php");
    exit;
}

// Define variables for filtering
$attended_by = $file_manager = $lead_type = $lead_status = $date_filter = "";
$start_date = $end_date = "";

// Process filter form submission
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["filter"])) {
    $attended_by = !empty($_POST["attended_by"]) ? $_POST["attended_by"] : "";
    $file_manager = !empty($_POST["file_manager"]) ? $_POST["file_manager"] : "";
    $lead_type = !empty($_POST["lead_type"]) ? $_POST["lead_type"] : "";
    $lead_status = !empty($_POST["lead_status"]) ? $_POST["lead_status"] : "";
    $date_filter = !empty($_POST["date_filter"]) ? $_POST["date_filter"] : "";
    
    if($date_filter == "custom" && !empty($_POST["start_date"]) && !empty($_POST["end_date"])) {
        $start_date = $_POST["start_date"];
        $end_date = $_POST["end_date"];
    }
}

// Process quick filter
$quick_filter = "";
if(isset($_GET["quick_filter"])) {
    $quick_filter = $_GET["quick_filter"];
    
    switch($quick_filter) {
        case "fresh":
            // Fresh - no comments updated
            $lead_status = "";
            break;
        case "attended":
            // Attended - Attended Status
            $lead_status = "Prospect - Attended";
            break;
        case "progress1":
            // Progress 1 - Quote Given
            $lead_status = "Prospect - Quote given";
            break;
        case "progress2":
            // Progress 2 - In Discussion
            $lead_status = "Neutral Prospect - In Discussion";
            break;
        case "followup":
            // Followup - Call back Scheduled
            $lead_status = "Call Back - Call Back Scheduled";
            break;
    }
}

// Create lead_status_map table if it doesn't exist
$create_table_sql = "CREATE TABLE IF NOT EXISTS lead_status_map (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    enquiry_id INT(11) NOT NULL,
    status_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (enquiry_id)
)";
mysqli_query($conn, $create_table_sql);

// Check for converted enquiries that are not in leads and add them
$check_sql = "SELECT e.* FROM enquiries e 
        LEFT JOIN converted_leads cl ON e.id = cl.enquiry_id 
        WHERE (e.status_id = 3 OR e.status_id = 'Converted') AND cl.enquiry_id IS NULL";

$check_result = mysqli_query($conn, $check_sql);

if(mysqli_num_rows($check_result) > 0) {
    while($enquiry = mysqli_fetch_assoc($check_result)) {
        // Generate enquiry number
        $enquiry_number = 'GH ' . sprintf('%04d', rand(1, 9999));
        
        // Insert into converted_leads table
        $insert_sql = "INSERT INTO converted_leads (enquiry_id, enquiry_number, travel_start_date, travel_end_date, booking_confirmed) 
                      VALUES (?, ?, NULL, NULL, 0)";
        $insert_stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($insert_stmt, "is", $enquiry['id'], $enquiry_number);
        mysqli_stmt_execute($insert_stmt);
    }
}



// Build the base SQL query with filters
$base_sql = "SELECT e.*, u.full_name as attended_by_name, d.name as department_name, 
        s.name as source_name, ac.name as campaign_name, ls.name as status_name,
        cl.enquiry_number, cl.travel_start_date, cl.travel_end_date, cl.booking_confirmed,
        lsm.status_name as lead_status, fm.full_name as file_manager_name
        FROM enquiries e 
        JOIN users u ON e.attended_by = u.id 
        JOIN departments d ON e.department_id = d.id 
        JOIN sources s ON e.source_id = s.id 
        LEFT JOIN ad_campaigns ac ON e.ad_campaign_id = ac.id 
        LEFT JOIN lead_status ls ON (e.status_id = ls.id OR e.status_id = ls.name) 
        LEFT JOIN converted_leads cl ON e.id = cl.enquiry_id
        LEFT JOIN lead_status_map lsm ON e.id = lsm.enquiry_id
        LEFT JOIN comments c ON e.id = c.enquiry_id
        LEFT JOIN users fm ON cl.file_manager_id = fm.id
        WHERE e.status_id = 3 AND cl.enquiry_id IS NOT NULL AND (cl.booking_confirmed = 0 OR cl.booking_confirmed IS NULL)";

// Simple count query to get total number of leads
$count_sql = "SELECT COUNT(DISTINCT e.id) 
        FROM enquiries e 
        LEFT JOIN converted_leads cl ON e.id = cl.enquiry_id
        WHERE e.status_id = 3 AND cl.enquiry_id IS NOT NULL AND (cl.booking_confirmed = 0 OR cl.booking_confirmed IS NULL)";

// Copy the base SQL to the main query
$sql = $base_sql; // Only converted leads that are not yet confirmed

// Check if current user is assigned as file manager to any leads
$file_manager_check_sql = "SELECT COUNT(*) as count FROM converted_leads WHERE file_manager_id = " . $_SESSION["id"];
$fm_check_result = mysqli_query($conn, $file_manager_check_sql);
$fm_check = mysqli_fetch_assoc($fm_check_result);
$is_file_manager = $fm_check['count'] > 0;

// If user is not admin and is assigned as file manager to leads, show only their assigned leads
if($_SESSION["role_id"] != 1 && $is_file_manager) {
    $sql .= " AND cl.file_manager_id = " . $_SESSION["id"];
}

// Add quick filter conditions
if($quick_filter == "fresh") {
    $sql .= " AND c.id IS NULL"; // No comments
}

$params = array();
$types = "";

if(!empty($attended_by)) {
    $sql .= " AND e.attended_by = ?";
    $params[] = $attended_by;
    $types .= "i";
}

if(!empty($file_manager)) {
    $sql .= " AND cl.file_manager_id = ?";
    $params[] = $file_manager;
    $types .= "i";
}

if(!empty($lead_type)) {
    $sql .= " AND cl.lead_type = ?";
    $params[] = $lead_type;
    $types .= "s";
}

if(!empty($lead_status) && $quick_filter != "fresh") {
    $sql .= " AND lsm.status_name = ?";
    $params[] = $lead_status;
    $types .= "s";
}

if(!empty($date_filter)) {
    switch($date_filter) {
        case "today":
            $sql .= " AND DATE(e.received_datetime) = CURDATE()";
            break;
        case "yesterday":
            $sql .= " AND DATE(e.received_datetime) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            break;
        case "this_week":
            $sql .= " AND YEARWEEK(e.received_datetime) = YEARWEEK(NOW())";
            break;
        case "this_month":
            $sql .= " AND MONTH(e.received_datetime) = MONTH(NOW()) AND YEAR(e.received_datetime) = YEAR(NOW())";
            break;
        case "this_year":
            $sql .= " AND YEAR(e.received_datetime) = YEAR(NOW())";
            break;
        case "custom":
            if(!empty($start_date) && !empty($end_date)) {
                $sql .= " AND DATE(e.received_datetime) BETWEEN ? AND ?";
                $params[] = $start_date;
                $params[] = $end_date;
                $types .= "ss";
            }
            break;
    }
}

// Add order by clause
$sql .= " ORDER BY e.received_datetime DESC";

// Execute the count query to get total number of leads
$count_stmt = mysqli_prepare($conn, $count_sql);
if(!empty($params)) {
    mysqli_stmt_bind_param($count_stmt, $types, ...$params);
}
mysqli_stmt_execute($count_stmt);
$count_result = mysqli_stmt_get_result($count_stmt);
$count_row = mysqli_fetch_array($count_result);
$total_records = $count_row ? $count_row[0] : 0;

// Prepare and execute the main query
$stmt = mysqli_prepare($conn, $sql);
if(!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Get users for filter dropdown
$users_sql = "SELECT * FROM users ORDER BY full_name";
$users = mysqli_query($conn, $users_sql);

// Get file managers for filter dropdown (same as users)
$file_managers = $users;

// Get lead statuses for filter dropdown
$statuses_sql = "SELECT * FROM lead_status ORDER BY id";
$statuses = mysqli_query($conn, $statuses_sql);

// Get lead status options for filter dropdown
$lead_status_options = [
    "Hot Prospect - Pipeline",
    "Prospect - Quote given",
    "Prospect - Attended",
    "Prospect - Awaiting Rate from Agent",
    "Neutral Prospect - In Discussion",
    "Future Hot Prospect - Quote Given (with delay)",
    "Future Prospect - Postponed",
    "Call Back - Call Back Scheduled",
    "Re-Opened - Re-Engaged Lead",
    "Re-Assigned - Transferred Lead",
    "Not Connected - No Response",
    "Not Interested - Cancelled",
    "Junk - Junk",
    "Duplicate - Duplicate",
    "Closed – Booked",
    "Change Request – Active Amendment",
    "Booking Value - Sale Amount"
];

// Check for confirmation message
$confirmation_message = "";
if(isset($_GET["confirmed"]) && $_GET["confirmed"] == 1) {
    $confirmation_message = "<div class='alert alert-success'>Lead successfully moved to Booking Confirmed.</div>";
} else if(isset($_GET["status_updated"]) && $_GET["status_updated"] == 1) {
    $confirmation_message = "<div class='alert alert-success'>Lead status updated successfully.</div>";
} else if(isset($_GET["error"]) && $_GET["error"] == 1) {
    $confirmation_message = "<div class='alert alert-danger'>Error updating lead status.</div>";
} else if(isset($_GET["error"]) && $_GET["error"] == 2) {
    $confirmation_message = "<div class='alert alert-danger'>Invalid request.</div>";
}
?>



<?php if(!empty($confirmation_message)): ?>
<div class="row">
    <div class="col-md-12">
        <?php echo $confirmation_message; ?>
    </div>
</div>
<?php endif; ?>

<!-- Include filter styles -->
<link rel="stylesheet" href="assets/css/filter-styles.css">

<!-- Quick Filter Tabs -->
<div class="card-box mb-20">
    <div class="pd-20">
        <h4 class="text-blue h4 mb-3">Quick Filters</h4>
        <div class="quick-filter-container">
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="all" <?php echo (!isset($_GET['quick_filter']) || $_GET['quick_filter'] == 'all') ? 'checked' : ''; ?> onchange="window.location.href='view_leads.php'">
                <span class="quick-filter-label">All</span>
            </label>
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="fresh" <?php echo (isset($_GET['quick_filter']) && $_GET['quick_filter'] == 'fresh') ? 'checked' : ''; ?> onchange="window.location.href='?quick_filter=fresh'">
                <span class="quick-filter-label">Fresh</span>
            </label>
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="attended" <?php echo (isset($_GET['quick_filter']) && $_GET['quick_filter'] == 'attended') ? 'checked' : ''; ?> onchange="window.location.href='?quick_filter=attended'">
                <span class="quick-filter-label">Attended</span>
            </label>
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="progress1" <?php echo (isset($_GET['quick_filter']) && $_GET['quick_filter'] == 'progress1') ? 'checked' : ''; ?> onchange="window.location.href='?quick_filter=progress1'">
                <span class="quick-filter-label">Progress 1</span>
            </label>
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="progress2" <?php echo (isset($_GET['quick_filter']) && $_GET['quick_filter'] == 'progress2') ? 'checked' : ''; ?> onchange="window.location.href='?quick_filter=progress2'">
                <span class="quick-filter-label">Progress 2</span>
            </label>
            <label class="quick-filter-item">
                <input type="radio" name="quick_filter" value="followup" <?php echo (isset($_GET['quick_filter']) && $_GET['quick_filter'] == 'followup') ? 'checked' : ''; ?> onchange="window.location.href='?quick_filter=followup'">
                <span class="quick-filter-label">Followup</span>
            </label>
        </div>
    </div>
</div>

<style>
.quick-filter-container {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.quick-filter-item {
    display: flex;
    align-items: center;
    cursor: pointer;
    margin: 0;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 20px;
    background: #fff;
    transition: all 0.2s ease;
    font-size: 13px;
    font-weight: 500;
}

.quick-filter-item:hover {
    background: #f8f9fa;
    border-color: #007bff;
}

.quick-filter-item input[type="radio"] {
    margin: 0 6px 0 0;
    transform: scale(0.9);
}

.quick-filter-item input[type="radio"]:checked + .quick-filter-label {
    color: #007bff;
    font-weight: 600;
}

.quick-filter-item:has(input[type="radio"]:checked) {
    background: #e3f2fd;
    border-color: #007bff;
    box-shadow: 0 2px 4px rgba(0,123,255,0.1);
}

.quick-filter-label {
    color: #495057;
    font-size: 13px;
    white-space: nowrap;
}
</style>

<!-- Filter Section -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Filters</h4>
    </div>
    <div class="pb-20 pd-20">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="filter-form">
            <div class="filter-row">
                <div class="form-group">
                    <label>Attended By</label>
                    <select class="custom-select" id="attended-by-filter" name="attended_by">
                        <option value="">All</option>
                        <?php mysqli_data_seek($users, 0); while($user = mysqli_fetch_assoc($users)): ?>
                            <option value="<?php echo $user['id']; ?>" <?php echo ($attended_by == $user['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($user['full_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>File Manager</label>
                    <select class="custom-select" id="file-manager-filter" name="file_manager">
                        <option value="">All</option>
                        <?php mysqli_data_seek($file_managers, 0); while($manager = mysqli_fetch_assoc($file_managers)): ?>
                            <option value="<?php echo $manager['id']; ?>" <?php echo ($file_manager == $manager['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($manager['full_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Lead Type</label>
                    <select class="custom-select" id="lead-type-filter" name="lead_type">
                        <option value="">All</option>
                        <option value="Hot" <?php echo ($lead_type == "Hot") ? 'selected' : ''; ?>>Hot</option>
                        <option value="Warm" <?php echo ($lead_type == "Warm") ? 'selected' : ''; ?>>Warm</option>
                        <option value="Cold" <?php echo ($lead_type == "Cold") ? 'selected' : ''; ?>>Cold</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Lead Status</label>
                    <select class="custom-select" id="lead-status-filter" name="lead_status">
                        <option value="">All</option>
                        <?php foreach($lead_status_options as $option): ?>
                            <option value="<?php echo $option; ?>" <?php echo ($lead_status == $option) ? 'selected' : ''; ?>>
                                <?php echo $option; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date Filter</label>
                    <select class="custom-select" id="date-filter" name="date_filter">
                        <option value="">All Time</option>
                        <option value="today" <?php echo ($date_filter == "today") ? 'selected' : ''; ?>>Today</option>
                        <option value="yesterday" <?php echo ($date_filter == "yesterday") ? 'selected' : ''; ?>>Yesterday</option>
                        <option value="this_week" <?php echo ($date_filter == "this_week") ? 'selected' : ''; ?>>This Week</option>
                        <option value="this_month" <?php echo ($date_filter == "this_month") ? 'selected' : ''; ?>>This Month</option>
                        <option value="this_year" <?php echo ($date_filter == "this_year") ? 'selected' : ''; ?>>This Year</option>
                        <option value="custom" <?php echo ($date_filter == "custom") ? 'selected' : ''; ?>>Custom Range</option>
                    </select>
                </div>
                <div id="custom-date-range" class="custom-date-range" <?php echo ($date_filter != "custom") ? 'style="display: none;"' : ''; ?>>
                    <div class="form-group">
                        <label for="start-date">Start Date</label>
                        <input type="date" class="form-control" id="start-date" name="start_date" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="form-group">
                        <label for="end-date">End Date</label>
                        <input type="date" class="form-control" id="end-date" name="end_date" value="<?php echo $end_date; ?>">
                    </div>
                </div>
                <div class="filter-buttons">
                    <button type="submit" name="filter" class="btn btn-primary">Apply Filters</button>
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Leads Table -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Leads (<?php echo $total_records; ?> total)</h4>
    </div>
    <div class="pb-20">
        <table class="data-table table stripe hover nowrap">
            <thead>
                <tr>
                     <th>Lead Date</th>
                    <th>Lead #</th>
                   
                    <th>Enquiry #</th>
                    <th>Customer Name</th>
                    <th>Mobile</th>
                    
                    <th>Email</th>
                    <th>Source</th>
                    <th>Campaign</th>
                    <th>Lead Status</th>
                    <th>Received Date</th>
                    <th>Attended By</th>
                    <th>File Manager</th>
                    <th>Department</th>
                    <th>Enquiries Status</th>
                    <th class="datatable-nosort">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr data-id="<?php echo $row['id']; ?>" class="<?php echo (isset($_GET['highlight']) && $_GET['highlight'] == $row['id']) ? 'highlight-row' : ''; ?>">
                 <td><?php echo isset($row['created_at']) ? date('d-m-Y', strtotime($row['created_at'])) : date('d-m-Y', strtotime($row['received_datetime'])); ?></td>   
                <td><?php echo htmlspecialchars($row['enquiry_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['lead_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['mobile_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['source_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['campaign_name'] ?? 'N/A'); ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <form method="post" action="save_status.php" style="display: flex; align-items: center;">
                                <?php 
                                // Get the current status directly from the database for this row
                                $status_check_sql = "SELECT status_name FROM lead_status_map WHERE enquiry_id = " . $row['id'];
                                $status_check_result = mysqli_query($conn, $status_check_sql);
                                $db_status = '';
                                if ($status_check_result && mysqli_num_rows($status_check_result) > 0) {
                                    $status_row = mysqli_fetch_assoc($status_check_result);
                                    $db_status = $status_row['status_name'];
                                }
                                ?>
                                <input type="hidden" name="enquiry_id" value="<?php echo $row['id']; ?>">
                                <select class="custom-select lead-status-select" name="status" style="min-width: 200px;" data-id="<?php echo $row['id']; ?>" onchange="toggleLastReasonDropdown(this, <?php echo $row['id']; ?>)">
                                    <option value="">Select Status</option>
                                    <option value="Hot Prospect - Pipeline" <?php echo ($db_status == "Hot Prospect - Pipeline") ? 'selected' : ''; ?>>Hot Prospect - Pipeline</option>
                                    <option value="Prospect - Quote given" <?php echo ($db_status == "Prospect - Quote given") ? 'selected' : ''; ?>>Prospect - Quote given</option>
                                    <option value="Prospect - Attended" <?php echo ($db_status == "Prospect - Attended") ? 'selected' : ''; ?>>Prospect - Attended</option>
                                    <option value="Prospect - Awaiting Rate from Agent" <?php echo ($db_status == "Prospect - Awaiting Rate from Agent") ? 'selected' : ''; ?>>Prospect - Awaiting Rate from Agent</option>
                                    <option value="Neutral Prospect - In Discussion" <?php echo ($db_status == "Neutral Prospect - In Discussion") ? 'selected' : ''; ?>>Neutral Prospect - In Discussion</option>
                                    <option value="Future Hot Prospect - Quote Given (with delay)" <?php echo ($db_status == "Future Hot Prospect - Quote Given (with delay)") ? 'selected' : ''; ?>>Future Hot Prospect - Quote Given (with delay)</option>
                                    <option value="Future Prospect - Postponed" <?php echo ($db_status == "Future Prospect - Postponed") ? 'selected' : ''; ?>>Future Prospect - Postponed</option>
                                    <option value="Call Back - Call Back Scheduled" <?php echo ($db_status == "Call Back - Call Back Scheduled") ? 'selected' : ''; ?>>Call Back - Call Back Scheduled</option>
                                    <option value="Re-Opened - Re-Engaged Lead" <?php echo ($db_status == "Re-Opened - Re-Engaged Lead") ? 'selected' : ''; ?>>Re-Opened - Re-Engaged Lead</option>
                                    <option value="Re-Assigned - Transferred Lead" <?php echo ($db_status == "Re-Assigned - Transferred Lead") ? 'selected' : ''; ?>>Re-Assigned - Transferred Lead</option>
                                    <option value="Not Connected - No Response" <?php echo ($db_status == "Not Connected - No Response") ? 'selected' : ''; ?>>Not Connected - No Response</option>
                                    <option value="Not Interested - Cancelled" <?php echo ($db_status == "Not Interested - Cancelled") ? 'selected' : ''; ?>>Not Interested - Cancelled</option>
                                    <option value="Junk - Junk" <?php echo ($db_status == "Junk - Junk") ? 'selected' : ''; ?>>Junk - Junk</option>
                                    <option value="Duplicate - Duplicate" <?php echo ($db_status == "Duplicate - Duplicate") ? 'selected' : ''; ?>>Duplicate - Duplicate</option>
                                    <option value="Closed – Booked" <?php echo ($db_status == "Closed – Booked") ? 'selected' : ''; ?>>Closed – Booked</option>
                                    <option value="Change Request – Active Amendment" <?php echo ($db_status == "Change Request – Active Amendment") ? 'selected' : ''; ?>>Change Request – Active Amendment</option>
                                    <option value="Booking Value - Sale Amount" <?php echo ($db_status == "Booking Value - Sale Amount") ? 'selected' : ''; ?>>Booking Value - Sale Amount</option>
                                </select>
                                
                                <?php 
                                // Get the current last reason from the database for this row
                                $db_last_reason = '';
                                // Check if last_reason column exists
                                $check_column_sql = "SHOW COLUMNS FROM lead_status_map LIKE 'last_reason'";
                                $column_result = mysqli_query($conn, $check_column_sql);
                                
                                if (mysqli_num_rows($column_result) > 0) {
                                    // Column exists, get the value
                                    $last_reason_check_sql = "SELECT last_reason FROM lead_status_map WHERE enquiry_id = " . $row['id'];
                                    $last_reason_check_result = mysqli_query($conn, $last_reason_check_sql);
                                    
                                    if ($last_reason_check_result && mysqli_num_rows($last_reason_check_result) > 0) {
                                        $last_reason_row = mysqli_fetch_assoc($last_reason_check_result);
                                        $db_last_reason = $last_reason_row['last_reason'];
                                    }
                                } else {
                                    // Column doesn't exist, add it
                                    $alter_table_sql = "ALTER TABLE lead_status_map ADD COLUMN last_reason VARCHAR(100) NULL";
                                    mysqli_query($conn, $alter_table_sql);
                                }
                                ?>
                                
                                <div id="last-reason-container-<?php echo $row['id']; ?>" class="last-reason-container" style="margin-bottom: 31px; padding: 0 0 0 20px; <?php echo ($db_status == "Not Interested - Cancelled") ? '' : 'display: none;'; ?>">
                                    <label for="last-reason-<?php echo $row['id']; ?>">Last Reason:</label>
                                    <select class="custom-select" name="last_reason" id="last-reason-<?php echo $row['id']; ?>" style="min-width: 200px;">
                                        <option value="">Select Reason</option>
                                        <option value="Amendments" <?php echo ($db_last_reason == "Amendments") ? 'selected' : ''; ?>>Amendments</option>
                                        <option value="FD(Fixed Departure)" <?php echo ($db_last_reason == "FD(Fixed Departure)") ? 'selected' : ''; ?>>FD(Fixed Departure)</option>
                                        <option value="High Flight Fare" <?php echo ($db_last_reason == "High Flight Fare") ? 'selected' : ''; ?>>High Flight Fare</option>
                                        <option value="Lack of Engagement" <?php echo ($db_last_reason == "Lack of Engagement") ? 'selected' : ''; ?>>Lack of Engagement</option>
                                        <option value="Lack of Resources" <?php echo ($db_last_reason == "Lack of Resources") ? 'selected' : ''; ?>>Lack of Resources</option>
                                        <option value="Lost to Competitor" <?php echo ($db_last_reason == "Lost to Competitor") ? 'selected' : ''; ?>>Lost to Competitor</option>
                                        <option value="No Decision" <?php echo ($db_last_reason == "No Decision") ? 'selected' : ''; ?>>No Decision</option>
                                        <option value="Not Interested" <?php echo ($db_last_reason == "Not Interested") ? 'selected' : ''; ?>>Not Interested</option>
                                        <option value="On Hold" <?php echo ($db_last_reason == "On Hold") ? 'selected' : ''; ?>>On Hold</option>
                                        <option value="Other Priorities" <?php echo ($db_last_reason == "Other Priorities") ? 'selected' : ''; ?>>Other Priorities</option>
                                        <option value="Own Travel Plans" <?php echo ($db_last_reason == "Own Travel Plans") ? 'selected' : ''; ?>>Own Travel Plans</option>
                                        <option value="Permit / Visa Issue" <?php echo ($db_last_reason == "Permit / Visa Issue") ? 'selected' : ''; ?>>Permit / Visa Issue</option>
                                        <option value="Plan Dropped" <?php echo ($db_last_reason == "Plan Dropped") ? 'selected' : ''; ?>>Plan Dropped</option>
                                        <option value="Postponed" <?php echo ($db_last_reason == "Postponed") ? 'selected' : ''; ?>>Postponed</option>
                                        <option value="Price Objection" <?php echo ($db_last_reason == "Price Objection") ? 'selected' : ''; ?>>Price Objection</option>
                                        <option value="Product /Service mismatch" <?php echo ($db_last_reason == "Product /Service mismatch") ? 'selected' : ''; ?>>Product /Service mismatch</option>
                                        <option value="Unresponsive" <?php echo ($db_last_reason == "Unresponsive") ? 'selected' : ''; ?>>Unresponsive</option>
                                    </select>
                                </div>
                                <?php 
                                // Check if cost file exists for this enquiry
                                $cost_file_check_sql = "SELECT id FROM tour_costings WHERE enquiry_id = " . $row['id'];
                                $cost_file_result = mysqli_query($conn, $cost_file_check_sql);
                                $has_cost_file = mysqli_num_rows($cost_file_result) > 0;
                                ?>
                                <?php if ($has_cost_file): ?>
                                    <button type="button" class="btn btn-link p-0 ml-2" onclick="showCostFileAlert()" disabled>
                                        <i class="icon-copy fa fa-check text-muted" aria-hidden="true" title="Cost file already exists"></i>
                                    </button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-link p-0 ml-2">
                                        <i class="icon-copy fa fa-check text-success" aria-hidden="true"></i>
                                    </button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </td>
                    <td><?php echo date('d-m-Y H:i', strtotime($row['received_datetime'])); ?></td>
                    <td><?php echo htmlspecialchars($row['attended_by_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['file_manager_name'] ?? 'Not Assigned'); ?></td>
                    <td><?php echo htmlspecialchars($row['department_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['status_name']); ?></td>
                    <td>
                        <div class="dropdown">
                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                <a class="dropdown-item" href="edit_enquiry.php?id=<?php echo $row['id']; ?>"><i class="dw dw-edit2"></i> Edit</a>
                                <?php 
                                // Show cost sheet link for specific statuses
                                $cost_sheet_statuses = [
                                    'Closed – Booked',
                                    'Prospect - Attended', 
                                    'Hot Prospect - Pipeline',
                                    'Prospect - Quote given',
                                    'Neutral Prospect - In Discussion'
                                ];
                                if(in_array($db_status, $cost_sheet_statuses)): 
                                ?>
                                <a class="dropdown-item" href="new_cost_file.php?id=<?php echo $row['id']; ?>"><i class="dw dw-file"></i> Cost File</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="#" onclick="moveToConfirmed(<?php echo $row['id']; ?>); return false;"><i class="dw dw-check"></i> Move to Confirmed</a>
                                <a class="dropdown-item" href="comments.php?id=<?php echo $row['id']; ?>&type=lead"><i class="dw dw-chat"></i> Comments</a>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Comment Modal -->
<div class="modal fade" id="add-comment-modal" tabindex="-1" role="dialog" aria-labelledby="add-comment-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="add-comment-modal-title">Comments</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="comments-container">
                    <!-- Comments will be loaded here -->
                </div>
                <hr>
                <form id="comment-form">
                    <input type="hidden" name="enquiry_id" id="enquiry-id">
                    <input type="hidden" name="table_id" id="table-id">
                    <div class="form-group">
                        <label for="comment">Add Comment</label>
                        <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Comment</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Function to toggle Last Reason dropdown visibility
function toggleLastReasonDropdown(selectElement, rowId) {
    var lastReasonContainer = document.getElementById('last-reason-container-' + rowId);
    if (selectElement.value === 'Not Interested - Cancelled') {
        lastReasonContainer.style.display = 'block';
    } else {
        lastReasonContainer.style.display = 'none';
    }
}

// Initialize all dropdowns on page load
document.addEventListener('DOMContentLoaded', function() {
    var statusSelects = document.querySelectorAll('.lead-status-select');
    statusSelects.forEach(function(select) {
        var rowId = select.getAttribute('data-id');
        toggleLastReasonDropdown(select, rowId);
    });
});

// Initialize DataTable with custom options
document.addEventListener('DOMContentLoaded', function() {
    window.addEventListener('load', function() {
        if (typeof $.fn.DataTable !== 'undefined') {
            // Destroy any existing DataTable instance
            if ($.fn.DataTable.isDataTable('.data-table')) {
                $('.data-table').DataTable().destroy();
            }
            
            // Initialize with custom options
            $('.data-table').DataTable({
                scrollCollapse: true,
                autoWidth: false,
                responsive: true,
                searching: false,  // Disable built-in search as we have custom filter
                ordering: true,
                paging: true,
                info: true,
                columnDefs: [{
                    targets: "datatable-nosort",
                    orderable: false,
                }],
                "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
                "language": {
                    "info": "_START_-_END_ of _TOTAL_ entries",
                    searchPlaceholder: "Search",
                    paginate: {
                        next: '<i class="ion-chevron-right"></i>',
                        previous: '<i class="ion-chevron-left"></i>'
                    }
                }
            });
        }
    });
});

function saveStatus(link, id) {
    var status = $('.lead-status-select[data-id="' + id + '"]').val();
    if (!status) {
        alert('Please select a status first');
        return false;
    }
    link.href = 'direct_save_status.php?id=' + id + '&status=' + encodeURIComponent(status);
    return true;
}

$(document).ready(function() {
    // Direct click handler for save buttons
    $('.save-status-btn').click(function() {
        var enquiryId = $(this).data('id');
        var status = $('.lead-status-select[data-id="' + enquiryId + '"]').val();
        
        if (!status) {
            alert('Please select a status');
            return;
        }
        
        var $button = $(this);
        var $icon = $button.find('i');
        
        // Show loading
        $icon.removeClass('fa-check').addClass('fa-spinner fa-spin');
        
        // Simple AJAX request
        $.post('save_lead_status.php', {
            enquiry_id: enquiryId,
            status: status
        }, function(response) {
            if (response.indexOf('success') !== -1) {
                // Success
                $icon.removeClass('fa-spinner fa-spin').addClass('fa-check');
            } else {
                // Error
                alert('Error saving status: ' + response);
                $icon.removeClass('fa-spinner fa-spin').addClass('fa-times');
                setTimeout(function() {
                    $icon.removeClass('fa-times').addClass('fa-check');
                }, 2000);
            }
        });
    });
});

// Function to show alert when cost file already exists
function showCostFileAlert() {
    alert('Cost file has already been created for this lead. Please use the "Cost File" option in the Actions menu to edit the existing cost file.');
}
</script>
<script>
    // Show/hide custom date range based on date filter selection
    document.getElementById('date-filter').addEventListener('change', function() {
        var customDateRange = document.getElementById('custom-date-range');
        if (this.value === 'custom') {
            customDateRange.style.display = 'flex';
        } else {
            customDateRange.style.display = 'none';
        }
    });
    
    // Function to move lead to confirmed
    function moveToConfirmed(id) {
        if (confirm('Are you sure you want to move this lead to Booking Confirmed?')) {
            // Create form data
            var formData = new FormData();
            formData.append('enquiry_id', id);
            
            // Send AJAX request
            fetch('move_to_confirmed.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                alert('Lead successfully moved to Booking Confirmed');
                // Reload the page to refresh the table
                window.location.href = 'view_leads.php?confirmed=1';
            })
            .catch(error => {
                alert('Error: ' + error);
            });
        }
    }
    
    // Set enquiry ID in comment modal and load comments
    $(document).ready(function() {
        
        $('.comment-link').on('click', function(e) {
            var enquiryId = $(this).data('id');
            var customerName = $(this).data('customer');
            console.log("Comment link clicked for enquiry ID:", enquiryId, "Customer:", customerName);
            
            // Set the modal title with customer name
            $('#add-comment-modal-title').text('Comments for ' + customerName);
            
            // Set form values
            $('#enquiry-id').val(enquiryId);
            $('#table-id').val('enquiries');
            
            // Load existing comments
            loadComments(enquiryId);
        });
        
        $('#add-comment-modal').on('show.bs.modal', function (event) {
            // Modal is being shown - nothing additional needed here
            // The click handler above will have already set everything up
        });
        
        // Function to load comments
        function loadComments(enquiryId) {
            console.log("Loading comments for enquiry ID:", enquiryId);
            $('#comments-container').html('<p>Loading comments...</p>');
            
            $.ajax({
                url: 'get_comments.php',
                type: 'GET',
                data: {
                    enquiry_id: enquiryId
                },
                success: function(response) {
                    console.log("Response received:", response);
                    try {
                        var data = JSON.parse(response);
                        console.log("Parsed data:", data);
                        if (data.success) {
                            var commentsHtml = '';
                            if (data.comments && data.comments.length > 0) {
                                data.comments.forEach(function(comment) {
                                    commentsHtml += '<div class="comment-box">' +
                                        '<div class="comment-header">' +
                                        '<span class="comment-user">' + comment.user_name + '</span>' +
                                        '<span class="comment-date">' + comment.created_at + '</span>' +
                                        '</div>' +
                                        '<div class="comment-body">' + comment.comment.replace(/\n/g, '<br>') + '</div>' +
                                        '</div>';
                                });
                            } else {
                                commentsHtml = '<p class="text-muted">No comments yet.</p>';
                            }
                            $('#comments-container').html(commentsHtml);
                        } else {
                            $('#comments-container').html('<p class="text-danger">Error loading comments: ' + data.message + '</p>');
                        }
                    } catch (e) {
                        console.error("Error parsing JSON:", e, response);
                        $('#comments-container').html('<p class="text-danger">Error processing response</p>');
                    }
                },
                error: function() {
                    $('#comments-container').html('<p class="text-danger">Error loading comments</p>');
                }
            });
        }
        
        // Initialize dropdown functionality
        $('.dropdown-toggle').dropdown();
        
        // Handle form submission via AJAX
        $('#comment-form').on('submit', function(e) {
            e.preventDefault();
            var enquiryId = $('#enquiry-id').val();
            var comment = $('#comment').val();
            
            $.ajax({
                url: 'add_comment.php',
                type: 'POST',
                data: {
                    enquiry_id: enquiryId,
                    comment: comment,
                    table_id: $('#table-id').val()
                },
                success: function(response) {
                    try {
                        var data = JSON.parse(response);
                        if (data.success) {
                            // Clear the textarea
                            $('#comment').val('');
                            
                            // Reload comments
                            loadComments(enquiryId);
                        } else {
                            alert('Error: ' + data.message);
                        }
                    } catch (e) {
                        alert('Error processing response');
                    }
                },
                error: function() {
                    alert('Error submitting comment');
                }
            });
        });
    });
</script>

<script src="view_leads_update.js"></script>

<?php
// Include footer
require_once "includes/footer.php";
?>