<?php
// Include header
require_once "includes/header.php";

// Check if user has privilege to access this page
if(!hasPrivilege('view_leads')) {
    header("location: index.php");
    exit;
}

// Handle delete action
if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id']) && isAdmin()) {
    $cost_file_id = intval($_GET['id']);
    
    // Delete cost file
    $delete_sql = "DELETE FROM tour_costings WHERE id = ?";
    $delete_stmt = mysqli_prepare($conn, $delete_sql);
    mysqli_stmt_bind_param($delete_stmt, "i", $cost_file_id);
    
    if(mysqli_stmt_execute($delete_stmt)) {
        $success_message = "Cost file deleted successfully!";
    } else {
        $error_message = "Error deleting cost file: " . mysqli_error($conn);
    }
}

// Get all cost files from tour_costings table
$sql = "SELECT tc.*, e.customer_name, e.mobile_number, e.email 
        FROM tour_costings tc 
        LEFT JOIN enquiries e ON tc.enquiry_id = e.id 
        ORDER BY tc.created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<div class="pd-20 card-box mb-30">
    <div class="clearfix mb-20">
        <div class="pull-left">
            <h4 class="text-blue h4">Cost Files</h4>
        </div>
    </div>
    
    <?php if(isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if(isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cost Sheet No</th>
                    <th>Guest Name</th>
                    <th>Mobile</th>
                    <th>Email</th>
                    <th>Package Cost</th>
                    <th>Currency</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($result) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['cost_sheet_number'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['guest_name'] ?? $row['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['mobile_number'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['currency']) . ' ' . number_format($row['package_cost'], 2); ?></td>
                            <td><?php echo htmlspecialchars($row['currency']); ?></td>
                            <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                        <i class="dw dw-more"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                        <a class="dropdown-item" href="edit_cost_file.php?id=<?php echo $row['id']; ?>"><i class="dw dw-edit2"></i> Edit</a>
                                        <?php if(isAdmin()): ?>
                                            <a class="dropdown-item" href="view_cost_sheets.php?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this cost file?');"><i class="dw dw-delete-3"></i> Delete</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center">No cost files found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Include footer
require_once "includes/footer.php";
?>