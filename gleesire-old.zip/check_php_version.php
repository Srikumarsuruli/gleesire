<?php
echo "PHP Version: " . phpversion();
echo "<br>";
echo "PHP Info:<br>";
phpinfo();
?>