<?php
require_once "config/database.php";

// Change travel_month column from DATE to VARCHAR to store month names
$sql = "ALTER TABLE converted_leads MODIFY COLUMN travel_month VARCHAR(20) NULL";

if(mysqli_query($conn, $sql)) {
    echo "Column travel_month changed to VARCHAR(20) successfully.";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>