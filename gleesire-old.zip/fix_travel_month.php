<?php
// Include database connection
require_once "includes/config.php";

// Alter the travel_month column to VARCHAR if it's currently DATE type
$sql = "ALTER TABLE converted_leads MODIFY COLUMN travel_month VARCHAR(20)";
if(mysqli_query($conn, $sql)) {
    echo "Database column travel_month modified successfully to VARCHAR(20)<br>";
} else {
    echo "Error modifying column: " . mysqli_error($conn) . "<br>";
}

echo "Done!";
?>